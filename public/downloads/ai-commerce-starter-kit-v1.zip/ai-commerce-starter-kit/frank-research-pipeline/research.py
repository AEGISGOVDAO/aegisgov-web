#!/usr/bin/env python3
"""
Frank's Daily AI Commerce Research Pipeline
Scans HN, Reddit, and product changelogs. Filters for actionable signals.
Runs locally via Qwen 7B — $0/month.

Usage: python3 research.py
Output: prints top 3 signals to stdout, saves to research-output.json
"""

import json
import subprocess
import time
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

OUTPUT_FILE = Path("research-output.json")

# ── Signal Sources ─────────────────────────────────────────────────────────────

CHANGELOG_URLS = [
    "https://hacker-news.firebaseio.com/v0/topstories.json",  # HN top 30
]

REDDIT_SOURCES = [
    ("ecommerce", "hot"),
    ("artificial", "hot"),
    ("ChatGPT", "hot"),
    ("shopify", "new"),
]

KEYWORD_TRIGGERS = [
    "perplexity shopping", "chatgpt shopping", "amazon rufus", "agentic",
    "llm commerce", "ai checkout", "product card", "in-chat purchase",
    "shopify ai", "structured data", "schema.org product",
]


# ── Qwen Integration ───────────────────────────────────────────────────────────

def qwen(prompt: str, timeout: int = 120) -> str:
    """Call local Qwen 7B via Ollama."""
    try:
        result = subprocess.run(
            ["ollama", "run", "qwen2.5:7b", prompt],
            capture_output=True, text=True, timeout=timeout
        )
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return ""
    except FileNotFoundError:
        print("ERROR: ollama not found. Install from https://ollama.com")
        return ""


def is_signal(title: str, text: str) -> bool:
    """Quick keyword filter before calling Qwen."""
    combined = (title + " " + text).lower()
    return any(kw in combined for kw in KEYWORD_TRIGGERS)


# ── Data Fetchers ──────────────────────────────────────────────────────────────

def fetch_json(url: str, retries: int = 2) -> dict | list | None:
    headers = {"User-Agent": "FrankAICommerce/1.0"}
    for _ in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=8) as r:
                return json.loads(r.read())
        except Exception:
            time.sleep(1)
    return None


def fetch_hn_stories(limit: int = 30) -> list[dict]:
    ids = fetch_json("https://hacker-news.firebaseio.com/v0/topstories.json")
    if not ids:
        return []
    stories = []
    for story_id in ids[:limit]:
        item = fetch_json(f"https://hacker-news.firebaseio.com/v0/item/{story_id}.json")
        if item and item.get("type") == "story":
            stories.append({
                "source": "HN",
                "title": item.get("title", ""),
                "text": item.get("text", "")[:300],
                "url": item.get("url", ""),
                "score": item.get("score", 0),
            })
        time.sleep(0.1)
    return stories


def fetch_reddit(subreddit: str, sort: str = "hot", limit: int = 10) -> list[dict]:
    url = f"https://www.reddit.com/r/{subreddit}/{sort}.json?limit={limit}"
    data = fetch_json(url)
    if not data:
        return []
    posts = []
    for child in data.get("data", {}).get("children", []):
        p = child.get("data", {})
        if p.get("stickied") or p.get("over_18"):
            continue
        posts.append({
            "source": f"r/{subreddit}",
            "title": p.get("title", ""),
            "text": p.get("selftext", "")[:300],
            "url": f"https://reddit.com{p.get('permalink', '')}",
            "score": p.get("score", 0),
        })
    return posts


# ── Signal Extraction ──────────────────────────────────────────────────────────

SIGNAL_PROMPT = """You are a commerce analyst. Read this item and determine if it's SIGNAL or NOISE.

SIGNAL = specific, actionable, affects how merchants operate TODAY
NOISE = hype, speculation, general trend, no merchant action required

Title: {title}
Text: {text}

If SIGNAL output exactly:
STATUS: SIGNAL
HEADLINE: [one sentence, must include tool name or number]
FACT: [specific stat or mechanic]
ACTION: [one concrete Shopify/ecommerce step this week]
URGENCY: HIGH / MEDIUM / LOW

If NOISE output exactly:
STATUS: NOISE

Nothing else."""


def analyze_item(item: dict) -> dict | None:
    if not is_signal(item["title"], item["text"]):
        return None  # skip Qwen call — not relevant

    prompt = SIGNAL_PROMPT.format(
        title=item["title"][:200],
        text=item["text"][:400]
    )
    raw = qwen(prompt, timeout=90)

    if "STATUS: NOISE" in raw or not raw:
        return None

    result = {
        "source": item["source"],
        "title": item["title"],
        "url": item.get("url", ""),
        "score": item.get("score", 0),
    }

    for line in raw.split("\n"):
        for field in ["HEADLINE", "FACT", "ACTION", "URGENCY"]:
            if line.startswith(f"{field}:"):
                result[field.lower()] = line[len(field)+1:].strip()

    if "headline" not in result:
        return None  # Qwen didn't follow format

    return result


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    print(f"\n🦅 Frank Research Pipeline — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("Scanning sources...\n")

    all_items = []

    # HN
    print("📡 Hacker News top stories...")
    hn = fetch_hn_stories(30)
    all_items.extend(hn)
    print(f"   {len(hn)} stories fetched")

    # Reddit
    for sub, sort in REDDIT_SOURCES:
        print(f"📡 r/{sub} ({sort})...")
        posts = fetch_reddit(sub, sort, 10)
        all_items.extend(posts)
        print(f"   {len(posts)} posts fetched")
        time.sleep(1)

    # Filter + deduplicate
    seen_titles = set()
    candidates = []
    for item in all_items:
        t = item["title"].lower()[:60]
        if t not in seen_titles and is_signal(item["title"], item["text"]):
            seen_titles.add(t)
            candidates.append(item)

    print(f"\n🔍 {len(candidates)} keyword matches — running Qwen analysis...")

    signals = []
    for i, item in enumerate(candidates[:15]):  # max 15 Qwen calls per run
        print(f"   [{i+1}/{min(len(candidates), 15)}] {item['title'][:60]}...")
        result = analyze_item(item)
        if result:
            signals.append(result)
            print(f"   ✅ SIGNAL: {result.get('headline', '')[:60]}")

    # Sort: HIGH urgency first, then by score
    urgency_rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    signals.sort(key=lambda x: (urgency_rank.get(x.get("urgency", "LOW"), 2), -x.get("score", 0)))

    top = signals[:3]

    print(f"\n📊 TOP {len(top)} SIGNALS\n{'='*50}")
    for i, s in enumerate(top, 1):
        print(f"\n[{i}] {s.get('headline', 'No headline')}")
        print(f"    FACT: {s.get('fact', '—')}")
        print(f"    ACTION: {s.get('action', '—')}")
        print(f"    URGENCY: {s.get('urgency', '—')} | Source: {s['source']}")

    # Save output
    output = {
        "date": datetime.now().isoformat(),
        "signals_found": len(signals),
        "top_signals": top,
    }
    with open(OUTPUT_FILE, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\n✅ Saved to {OUTPUT_FILE}")
    print("\n🦅 Done. Run daily at 7am for fresh signal.")


if __name__ == "__main__":
    main()
