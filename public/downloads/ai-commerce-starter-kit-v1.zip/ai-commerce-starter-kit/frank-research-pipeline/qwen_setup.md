# Running Qwen 7B Locally — Frank's Setup

This is the exact setup I run. No Docker needed. Ollama is the only install.

---

## System Requirements

| Machine | Minimum | Frank's Setup |
|---|---|---|
| Mac M-series | 8GB RAM, M1 | Mac mini M4 Pro, 24GB |
| Windows/Linux | 16GB RAM, modern CPU | Any recent GPU helps |

Qwen 7B runs on CPU-only. It's slower (30s/query vs 5s on M4), but it works.

---

## Step 1: Install Ollama

**Mac:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```
Or: download from https://ollama.com — drag to Applications, done.

**Windows/Linux:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

Verify:
```bash
ollama --version
# ollama version is 0.x.x
```

---

## Step 2: Pull Qwen 7B

```bash
ollama pull qwen2.5:7b
```

This downloads ~4.7GB. Takes 5-10 minutes depending on connection.

Verify it works:
```bash
ollama run qwen2.5:7b "What is Perplexity Shopping and why does it matter for ecommerce?"
```

You'll get a response in 5-30 seconds depending on your hardware.

---

## Step 3: Python Integration (Frank's exact pattern)

Every script I run uses this pattern:

```python
import subprocess

def qwen(prompt: str, max_tokens: int = 200) -> str:
    """Call local Qwen 7B. Returns stripped text output."""
    result = subprocess.run(
        ["ollama", "run", "qwen2.5:7b", prompt],
        capture_output=True,
        text=True,
        timeout=120  # 2min max — adjust down on fast hardware
    )
    return result.stdout.strip()

# Usage
signal = qwen("""
You are a commerce analyst. Read this news item and extract:
1. ONE specific fact with a number
2. ONE action a Shopify merchant should take today

News: Perplexity Shopping now completes purchases in-chat using Buy buttons.

Output format:
FACT: [specific stat]
ACTION: [one concrete step]
""")

print(signal)
```

That's it. No API keys. No rate limits. No cost. Runs offline.

---

## Step 4: Research Settings

For signal extraction (what Frank uses):
```python
# Temperature is set via modelfile if needed, but default works fine
# Frank just uses raw subprocess calls — no temperature tuning needed
# for research/classification tasks

# Key: keep prompts SHORT and SPECIFIC
# Bad:  "Tell me about AI commerce trends"
# Good: "Extract ONE specific fact with a number from this text: [text]"
```

For longer analysis tasks, bump timeout:
```python
result = subprocess.run(
    ["ollama", "run", "qwen2.5:7b", prompt],
    capture_output=True, text=True,
    timeout=300  # 5 minutes for complex tasks
)
```

---

## Cost Comparison (real numbers)

| Model | Cost per 1M tokens | Frank's monthly cost |
|---|---|---|
| Qwen 7B (local) | **$0** | **$0** |
| Claude Sonnet 4 | ~$3/M in, $15/M out | $60/mo at 10M tokens |
| GPT-4o | ~$2.50/M in, $10/M out | $50/mo at 10M tokens |
| Gemini Flash | $0.30/M | $3/mo at 10M tokens |

Frank's rule: Qwen handles 70% of work. Claude for strategy only, $2/day cap.

---

## Common Issues

**"ollama: command not found"**
Add to PATH: `export PATH=$PATH:/usr/local/bin` then `source ~/.zshrc`

**Slow response on CPU-only Mac Intel**
Normal. Takes 30-60s/query. For batch jobs, run overnight.

**Out of memory**
Close other apps. Qwen 7B needs ~5GB RAM when loaded.

**Model gives garbage output**
Prompt too vague. Add explicit output format instructions (see Step 3 example).
