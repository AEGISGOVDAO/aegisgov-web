# Perplexity Shopping Optimization Guide
### For Commerce Operators | By Frank — aegisgov.ai/frank

---

## What Perplexity Shopping Is (and Why It's Different)

Perplexity Shopping shows a "Buy" button inside the chat interface. The shopper searches, sees product cards with prices and images, clicks Buy — and the transaction completes **without leaving Perplexity**. No redirect to your store. No cart page. No checkout friction.

**The mechanic:** Perplexity's crawler reads structured product data from your site. If your data is clean and complete, you get surfaced. If it's not, you're invisible.

This is different from Google Shopping, which relies on Google Merchant Center (manual feed). Perplexity reads your site's structured data directly.

**Why it matters now:** Most merchants haven't optimized for this yet. The window to be a first-mover is open.

---

## How Perplexity's Crawler Works

1. Perplexity's bot (`PerplexityBot`) crawls product pages like a standard web crawler
2. It reads `<script type="application/ld+json">` blocks — this is Schema.org structured data
3. It extracts: name, price, availability, description, brand, images, SKU
4. Products with complete, accurate data get surfaced in shopping results
5. Products with missing fields, inconsistent pricing, or blocked crawlers get skipped

**Check if you're being crawled:**
Look in your server logs for: `PerplexityBot`

Or check robots.txt — make sure you're not blocking it:
```
# BAD — blocks Perplexity
User-agent: PerplexityBot
Disallow: /

# GOOD — allows Perplexity
User-agent: PerplexityBot
Allow: /
```

---

## Step-by-Step: Shopify

### Option A: Automated (Recommended)

Shopify generates basic Schema.org markup automatically, but it's often incomplete. Use a structured data app:

1. Go to **Shopify Admin → Apps → App Store**
2. Search: "Schema App" or "JSON-LD for SEO" (both work, JSON-LD for SEO is cheaper)
3. Install and run their product audit
4. Fix any flagged fields — focus on: `price`, `availability`, `description`, `image`

### Option B: Manual (Free, more control)

Add this to your product page template (Liquid):

```liquid
{% comment %} Add to product.liquid, inside <head> {% endcomment %}
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Product",
  "name": "{{ product.title | escape }}",
  "image": [
    "{{ product.featured_image | img_url: 'master' }}"
  ],
  "description": "{{ product.description | strip_html | escape | truncate: 500 }}",
  "brand": {
    "@type": "Brand",
    "name": "{{ product.vendor | escape }}"
  },
  "sku": "{{ product.selected_or_first_available_variant.sku }}",
  "offers": {
    "@type": "Offer",
    "url": "{{ shop.url }}{{ product.url }}",
    "priceCurrency": "{{ cart.currency.iso_code }}",
    "price": "{{ product.selected_or_first_available_variant.price | money_without_currency }}",
    "availability": "{% if product.available %}https://schema.org/InStock{% else %}https://schema.org/OutOfStock{% endif %}",
    "seller": {
      "@type": "Organization",
      "name": "{{ shop.name }}"
    }
  }
}
</script>
```

**Where to put it:** Shopify Admin → Online Store → Themes → Edit Code → `templates/product.liquid` or `sections/product-template.liquid`

---

## Step-by-Step: Non-Shopify (Custom / WooCommerce)

### WooCommerce
Install the **Yoast WooCommerce SEO** plugin — it handles Schema.org product markup automatically. After install, verify with Google's Rich Results Test (below).

### Custom Sites
Add this JSON-LD to each product page's `<head>`:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Product",
  "name": "Your Product Name",
  "image": ["https://yoursite.com/product-image.jpg"],
  "description": "Specific, accurate product description. Min 100 characters.",
  "brand": {
    "@type": "Brand",
    "name": "Your Brand"
  },
  "sku": "YOUR-SKU-123",
  "offers": {
    "@type": "Offer",
    "url": "https://yoursite.com/product-url",
    "priceCurrency": "USD",
    "price": "29.99",
    "priceValidUntil": "2027-01-01",
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": "Your Store Name"
    }
  }
}
</script>
```

**Critical fields — don't skip these:**
- `price` — must match what's shown on the page
- `availability` — InStock / OutOfStock / PreOrder
- `image` — high-res, direct URL, no redirects
- `description` — at least 100 characters, specific to this product

---

## The 5 Fields Perplexity Prioritizes

In order of importance based on testing:

1. **name** — exact product name, no keyword stuffing
2. **price + priceCurrency** — must be accurate and current
3. **availability** — InStock beats OutOfStock (obviously), but accuracy matters more
4. **description** — specific features, not marketing copy. "Waterproof, 500ml, BPA-free" beats "Amazing water bottle you'll love"
5. **image** — square or 1:1 ratio, min 800px, direct URL (no CDN redirect chains)

---

## Verify You're Indexed

**Test 1: Google Rich Results Test**
Go to: https://search.google.com/test/rich-results
Paste your product URL. It should show "Product" rich results with no errors.

**Test 2: Schema.org Validator**
Go to: https://validator.schema.org
Paste your product page URL. Check for errors on the Product type.

**Test 3: Perplexity direct search**
In Perplexity, search: "buy [your product name]"
If your product card appears, you're indexed. If not, check the above.

---

## The First-Mover Window

Perplexity Shopping launched in late 2024. Most merchants have not optimized for it. Google Shopping optimization has been the default for 15 years — the playbooks exist, the tools exist, everyone does it.

Perplexity Shopping optimization is still early. The merchants who get structured data right now will dominate those product searches while everyone else is still catching up.

This window closes as Perplexity scales. Act now.
