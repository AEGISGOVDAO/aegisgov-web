# Amazon Rufus — Writing Product Listings for AI-Mediated Search
### For Amazon Sellers | By Frank — aegisgov.ai/frank

---

## What Amazon Rufus Is

Rufus is Amazon's AI shopping assistant. It's built into the Amazon app and desktop site — the search bar you've used for 20 years now has an AI layer on top of it.

**The scale:** Amazon confirmed Rufus now touches 35% of product searches. That's not a beta test. It's the default experience for a third of your Amazon traffic.

**What Rufus does differently:**
- Interprets intent, not keywords ("what's a good gift for a 7-year-old boy who likes building")
- Answers product questions ("is this waterproof?" "will it fit a 6-foot person?")
- Compares products side-by-side when asked
- Summarizes reviews and surfaces common complaints

If your listing doesn't answer the questions Rufus is being asked, you don't get surfaced.

---

## How Rufus Reads Your Listing

Rufus reads these fields in order of weight:

1. **Title** — parsed first for product type, key specs, brand
2. **Bullet points (Key Features)** — highest-weight structured content
3. **Product description** — supports bullet points
4. **A+ Content / Brand Story** — parsed but lower weight
5. **Q&A section** — heavily weighted for question-answering queries
6. **Reviews** — Rufus synthesizes common themes from reviews

The Q&A section is the most underused and highest-leverage field for Rufus optimization.

---

## Rewriting Titles for Rufus

**Old pattern (keyword-stuffed for A9 algorithm):**
"Dog Leash 6ft Dog Leash Retractable Heavy Duty Dog Leash Nylon Dog Leash for Large Dogs"

**Rufus-readable pattern:**
"[Brand] Nylon Dog Leash — 6ft, Heavy-Duty, for Large Dogs (50-100 lbs)"

**Rules:**
- Brand first (Rufus uses brand to filter "brand X vs brand Y" comparisons)
- Product type clear in first 3 words
- One key spec (length, size, capacity, weight limit)
- No keyword repetition — Rufus reads semantically, repetition hurts readability
- Max 200 characters

---

## Rewriting Bullet Points for AI Comprehension

Rufus reads bullets as structured facts. Write them as answers to questions.

**Old style (feature-focused):**
- Heavy-duty nylon construction
- 6-foot length
- Padded handle for comfort
- Reflective stitching for safety

**Rufus-readable (question-answer format):**
- **Built for dogs 50-100 lbs:** Heavy-duty nylon rated to 300 lbs tensile strength — won't snap under pressure from large breeds
- **Full 6-foot range without tangling:** Single-piece construction, no clips or joints that catch. Lays flat when coiled.
- **Usable in dark or low-light:** 1-inch reflective strip along full length, visible at 200 feet in headlights
- **Won't cause hand fatigue on long walks:** 4-inch neoprene padded handle with non-slip grip — tested for 2-hour walks

**The pattern:** Lead with the use case or concern, then the spec that addresses it.

---

## The Q&A Section Strategy

This is the highest ROI optimization most sellers ignore.

Rufus heavily weights the Q&A section because it's literally designed to answer questions — which is exactly what Rufus does.

**Step 1: Seed your own Q&As**
You can answer Q&As yourself (as the brand). Customers can also ask questions that you answer.

**Questions to seed (for a leash example):**
- "Is this leash strong enough for a 90-pound dog?"
- "Will this fit a large breed like a German Shepherd?"
- "Is this suitable for dogs that pull hard?"
- "Can this be used in rain?"
- "Does the handle feel comfortable for long walks?"

**Step 2: Write answers Rufus can parse**
```
Q: Is this leash strong enough for a 90-pound dog?
A: Yes. This leash is rated to 300 lbs tensile strength and designed for dogs 50-100 lbs. 
   We've tested it with Labradors and German Shepherds at 85-95 lbs with no issues. 
   If your dog weighs over 100 lbs, we recommend our XL version (ASIN: B0XXXXX).
```

Answer format: Direct yes/no first → spec that proves it → specific use case example → optional upsell or alternative.

---

## Amazon Rufus vs. Traditional A9 SEO

| Factor | A9 (old algorithm) | Rufus (AI layer) |
|---|---|---|
| Keyword repetition | Helps | Hurts (reduces readability) |
| Q&A section | Low weight | HIGH weight |
| Review sentiment | Indirect | Direct — Rufus synthesizes reviews |
| Bullet structure | Keywords in bullets | Feature-benefit pairs |
| Title length | Longer = more keywords | Shorter = more readable |
| Description | Supports title keywords | Supports bullet facts |

You don't have to choose — optimize for Rufus and A9 performance stays the same or improves.

---

## 10-Minute Listing Audit

Pick your top 5 ASINs by revenue. For each:

**Title:**
- [ ] Brand appears first
- [ ] Product type clear in first 3 words
- [ ] At least one specific spec (size/weight/capacity)
- [ ] No keyword repetition
- [ ] Under 200 characters

**Bullets:**
- [ ] Each bullet leads with a use case or concern
- [ ] Each bullet includes a specific spec or measurement
- [ ] No generic phrases ("high quality", "premium", "best in class")
- [ ] All 5 bullet slots used

**Q&A:**
- [ ] At least 5 Q&As seeded
- [ ] Top purchase objections addressed
- [ ] Answers start with direct yes/no
- [ ] Includes specific specs in answers

**Backend keywords:**
- [ ] No repetition of title/bullet keywords (waste of space)
- [ ] Include synonyms, regional spellings, use cases not in bullets

---

## What Rufus Can't Do (Yet)

- Read images (it reads alt text and titles, but not image content)
- Access external URLs (don't put links in your listings hoping Rufus follows them)
- Compare your product to competitors not on Amazon

These are current limitations. Amazon is expanding Rufus capabilities quarterly.
