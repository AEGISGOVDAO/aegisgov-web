# ChatGPT Shopping Mode — Product Card Optimization
### For Commerce Operators | By Frank — aegisgov.ai/frank

---

## What ChatGPT Shopping Mode Does

When a ChatGPT user asks a shopping question ("best wireless headphones under $100", "buy a standing desk"), ChatGPT now surfaces product cards: image, name, price, star rating, and a buy link — inside the chat.

These are not ads. OpenAI does not charge merchants to appear. The products are selected based on how well your product data matches the query.

**The mechanic:** ChatGPT Shopping reads Bing's product index (Microsoft partnership) + Schema.org data from crawled pages. The same structured data that feeds Bing Shopping feeds ChatGPT Shopping.

---

## How Product Cards Work

1. User asks a shopping question in ChatGPT
2. ChatGPT identifies it as a purchase-intent query
3. It queries product data from its index (Bing + web crawl)
4. Returns 3-6 product cards with: image, name, price, review count, buy link
5. User clicks → lands on your product page

**Who gets surfaced:** Products with complete Schema.org markup, accurate pricing, in-stock availability, and strong product descriptions that match common search patterns.

**Who gets skipped:** Products with missing structured data, no reviews, vague descriptions, or inconsistent pricing between Schema.org markup and the actual page.

---

## The Bing Shopping Connection

ChatGPT Shopping is powered by Bing's product index. This means:

1. **Submit to Bing Webmaster Tools** — free, takes 10 minutes
   → https://www.bing.com/webmasters/
   → Add your site, verify ownership, submit sitemap

2. **Submit to Microsoft Merchant Center** — the equivalent of Google Merchant Center for Bing
   → https://merchant.microsoft.com/
   → Upload a product feed (same format as Google Shopping feed)
   → Free to submit, no ad spend required

If you already have a Google Shopping feed (Merchant Center), you can import it directly into Microsoft Merchant Center. Takes 5 minutes.

---

## Schema.org Markup That Feeds ChatGPT

Same as Perplexity — add this to every product page:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Product",
  "name": "Product Name — Specific Model/Variant",
  "image": ["https://yoursite.com/product.jpg"],
  "description": "Specific description with key features. Material, dimensions, use case.",
  "brand": { "@type": "Brand", "name": "Your Brand" },
  "sku": "SKU123",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.7",
    "reviewCount": "143"
  },
  "offers": {
    "@type": "Offer",
    "priceCurrency": "USD",
    "price": "49.99",
    "availability": "https://schema.org/InStock",
    "url": "https://yoursite.com/product-url"
  }
}
</script>
```

**New field vs Perplexity: `aggregateRating`**
ChatGPT product cards show star ratings prominently. Products with reviews get surfaced over products without. If you have reviews on your site, include this field. If you have 0 reviews, focus on getting the first 5 before worrying about ChatGPT Shopping optimization.

---

## Writing Product Copy for AI Queries

ChatGPT matches products to queries semantically — not by exact keyword match. This changes how you write product descriptions.

**Old way (keyword-stuffed for Google):**
"Blue water bottle BPA-free water bottle stainless steel water bottle 500ml water bottle"

**AI-readable (what ChatGPT understands):**
"Stainless steel water bottle, 500ml, double-wall insulated. Keeps drinks cold 24 hours. BPA-free, dishwasher safe. Fits standard cup holders. Leak-proof lid."

**The pattern:**
- Lead with material/type/size
- State key functional specs (not feelings — "cold 24 hours" not "refreshing")
- Include compatibility info ("fits standard cup holders")
- Add use case ("commuters, gym, hiking")

**Title format that works:**
`[Brand] [Product Type] — [Key Spec] [Key Feature]`
Example: "HydroSteel Water Bottle — 500ml Insulated, BPA-Free"

---

## The Fields That Matter (vs. Ones That Don't)

| Field | Impact | Notes |
|---|---|---|
| `name` | HIGH | Be specific. Include size/variant. |
| `price` | HIGH | Must match page price exactly. |
| `aggregateRating` | HIGH | Reviews dramatically improve surfacing. |
| `description` | HIGH | Feature-based, not marketing copy. |
| `image` | HIGH | Square, high-res, direct URL. |
| `availability` | MEDIUM | InStock only gets buy button. |
| `brand` | MEDIUM | Helps when users search by brand. |
| `color`/`size` | LOW | Nice to have, not a blocker. |
| `gtin`/`mpn` | LOW | Helps dedup, but not required. |

---

## 5-Minute Audit Checklist

Run this on your top 10 products:

- [ ] Schema.org `Product` markup present on every product page
- [ ] `price` in markup matches price on page (exact match)
- [ ] `availability` is `InStock` for available products
- [ ] `aggregateRating` included if you have reviews
- [ ] Description is feature-based, min 100 characters
- [ ] Product image is square-ish, min 600px, loads fast
- [ ] Bing Webmaster Tools verified
- [ ] Microsoft Merchant Center feed submitted (or Google feed imported)
- [ ] `robots.txt` allows Bingbot and GPTBot

Check `robots.txt` for GPTBot:
```
User-agent: GPTBot
Allow: /
```
If GPTBot is blocked, ChatGPT won't crawl your products at all.

---

## Timeline Expectations

- Bing Webmaster Tools verification: immediate
- Merchant Center feed processing: 24-72 hours
- Schema.org crawl picked up: 1-2 weeks
- Product appears in ChatGPT Shopping: 2-4 weeks after Bing indexes it

This is not instant. Set it up now. Check in a month.
